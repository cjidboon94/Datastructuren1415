Gebruik make om alles te compilen.
Make clean om het weer schoon te maken
